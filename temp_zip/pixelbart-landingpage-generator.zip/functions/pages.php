<?php
defined('ABSPATH') or exit;

function pixelbart_landing_get_pages(int $page = 1, int $limit = 10, ?string $search = null)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $offset = max(0, ($limit * $page) - $limit);

    $sql = "SELECT * FROM $table";

    if (!is_null($search) && trim($search) !== '') {
        $search = sanitize_text_field($search);

        $sql .= " WHERE page_location LIKE '%$search%'";
        $sql .= " OR page_name LIKE '%$search%'";
        $sql .= " OR page_url LIKE '%$search%'";
    }

    $sql .= " ORDER BY id DESC LIMIT $offset,$limit";

    return $wpdb->get_results($sql);
}

function pixelbart_landing_get_sitemap_pages()
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    return $wpdb->get_results("SELECT page_url, updated_at FROM $table ORDER BY updated_at DESC", ARRAY_A);
}

function pixelbart_landing_get_total_pages(?string $search = null)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $sql = "SELECT COUNT(id) FROM $table";

    if (!is_null($search) && trim($search) !== '') {
        $search = sanitize_text_field($search);

        $sql .= " WHERE page_location LIKE '%$search%'";
        $sql .= " OR page_name LIKE '%$search%'";
        $sql .= " OR page_url LIKE '%$search%'";
    }

    return $wpdb->get_var($sql);
}

function pixelbart_landing_get_max_num_pages(int $limit = 10, ?string $search = null)
{
    $count = pixelbart_landing_get_total_pages($search);

    if ($count > 0) {
        return ceil($count / $limit);
    }

    return 1;
}

function pixelbart_landing_get_pages_query(int $page = 1, int $limit = 10, ?string $search = null)
{
    $pages = pixelbart_landing_get_pages($page, $limit, $search);

    $query = new \WP_Query();

    $query->posts = $pages;
    $query->paged = $page;
    $query->posts_per_page = 10;
    $query->max_num_pages = pixelbart_landing_get_max_num_pages($limit, $search);
    $query->found_posts = count($pages);
    $query->post_count = pixelbart_landing_get_total_pages($search);

    return $query;
}

function pixelbart_landing_get_page(string $name)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $sql = "SELECT * FROM $table WHERE page_name = %s";

    return $wpdb->get_row($wpdb->prepare($sql, $name));
}

function pixelbart_landing_get_page_by_id(int $id)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $sql = "SELECT * FROM $table WHERE id = %d";

    return $wpdb->get_row($wpdb->prepare($sql, $id));
}

function pixelbart_landing_update_page(int $id, array $data)
{
    $page = pixelbart_landing_get_page_by_id($id);

    $default = [
        'page_name' => $page->page_name,
        'page_url' => $page->page_url,
        'page_user' => $page->page_user,
        'page_template' => $page->page_template,
        'page_location' => $page->page_location,
    ];

    $update_data = shortcode_atts($default, $data);
    $rewrite_base = pixelbart_landing_get_option('rewrite_base', 'service');

    if ($update_data['page_template'] !== $page->page_template) {
        $template_page = get_post($update_data['page_template']);
        $update_data['page_name'] = sprintf('%s in %s', $template_page->post_title, $update_data['page_location']);
        $update_data['page_url'] = site_url('/' . $rewrite_base . '/' . sanitize_title($update_data['page_location'] . ' ' . $template_page->post_title));
    }

    extract($update_data);

    if (is_null($page_name) || trim($page_name) === '') {
        return null;
    }

    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $wpdb->update($table, $update_data, ['id' => $id]);

    return pixelbart_landing_get_page_by_id($id);
}

function pixelbart_landing_insert_page(array $data)
{
    $default = [
        'page_name' => null,
        'page_url' => null,
        'page_user' => get_current_user_id(),
        'page_template' => null,
        'page_location' => null,
    ];

    $insert_data = shortcode_atts($default, $data);

    extract($insert_data);

    if (is_null($page_name) || trim($page_name) === '') {
        return null;
    }

    if (pixelbart_landing_get_page($page_name)) {
        return null;
    }

    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $wpdb->insert($table, $insert_data);

    return $wpdb->insert_id;
}

function pixelbart_landing_extract_query_vars(string $url)
{
    $segments = explode('/', parse_url($url, PHP_URL_PATH));
    $rewrite_base = pixelbart_landing_get_option('rewrite_base', 'service');

    $pxbt_landing_base = '';
    $pxbt_landing_page = '';

    if (in_array($rewrite_base, $segments)) {
        $index = array_search($rewrite_base, $segments);
        if (isset($segments[$index + 1])) {
            $pxbt_landing_base = $rewrite_base;
            $pxbt_landing_page = $segments[$index + 1];
        }
    }

    $result = new stdClass();
    $result->base = $pxbt_landing_base;
    $result->page = $pxbt_landing_page;

    return $result;
}

function pixelbart_landing_find_page_by_query_vars(string $base, string $page)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    $like = '%' . $base . '/' . $page . '%';

    $sql = "SELECT * FROM $table WHERE page_url LIKE '$like'";

    $row = $wpdb->get_row($sql);

    return $row;
}

function pixelbart_landing_get_location_from_title(string $title)
{
    $start = strpos($title, '[');

    $end = strpos($title, ']');

    $title = substr($title, $start + 1, $end - $start - 1);

    return $title;
}

function pixelbart_landing_remove_page(int $id)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_pages';

    return $wpdb->delete($table, ['id' => $id]) ? 1 : 0;
}