<?php
defined('ABSPATH') or exit;

function pixelbart_Landing_get_locations(string $location, int $radius = 15)
{
    $endpoint = 'https://api.pixelbart.de/locations/search';

    $params = [
        'token' => PIXELBART_LANDING_GENERATOR_API,
        'term' => $location,
        'radius' => $radius,
    ];

    $response = wp_remote_get($endpoint, [
        'body' => $params,
    ]);

    $json = wp_remote_retrieve_body($response);

    return json_decode($json);
}
