<?php
defined('ABSPATH') or exit;

function pixelbart_landing_get_option(string $name, $default = '')
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_options';

    $sql = "SELECT option_value FROM $table WHERE option_name = %s";

    $result = $wpdb->get_var($wpdb->prepare($sql, $name));

    if ($result !== null) {
        $decoded_result = json_decode($result);

        if ($decoded_result !== null) {
            return $decoded_result;
        } else {
            return $result;
        }
    } else {
        return $default;
    }
}

function pixelbart_landing_set_option(string $name, $value)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_options';

    $result = $wpdb->get_results("SELECT * FROM $table WHERE option_name = '$name'");

    $value = (is_array($value)) ? json_encode($value) : $value;

    if ($name === 'rewrite_base') {
        $rewrite_base = pixelbart_landing_get_option('rewrite_base', 'service');
    }

    if (count($result) > 0) {
        $wpdb->update(
            $table,
            ['option_value' => $value],
            ['option_name' => $name],
            ['%s'],
            ['%s']
        );
    } else {
        $wpdb->insert(
            $table,
            ['option_name' => $name, 'option_value' => $value],
            ['%s', '%s']
        );
    }

    if ($name === 'rewrite_base') {
        global $wpdb;

        $table_name = $wpdb->prefix . 'pxbt_landing_pages';

        $rows = $wpdb->get_results("SELECT * FROM $table_name WHERE page_url LIKE '%/$rewrite_base/%'");

        if ($rows) {
            foreach ($rows as $row) {
                $wpdb->update(
                    $table_name,
                    [
                        'page_url' => str_replace('/' . $rewrite_base . '/', '/' . $value . '/', $row->page_url)
                    ],
                    [
                        'id' => $row->id,
                    ]
                );
            }
        }

        flush_rewrite_rules();
    }
}

function pixelbart_landing_delete_option(string $name)
{
    global $wpdb;

    $table = $wpdb->prefix . 'pxbt_landing_options';

    $wpdb->delete($table, array(
        'option_name' => $name
    ));
}
