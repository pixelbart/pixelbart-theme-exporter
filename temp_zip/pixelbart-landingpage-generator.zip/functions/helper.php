<?php
defined('ABSPATH') or exit;

function pixelbart_Landing_get_templates()
{
    $pages = get_pages();
    $pages_array = array();

    foreach ($pages as $page) {
        $pages_array[$page->ID] = $page->post_title;
    }

    return $pages_array;
}

function pixelbart_Landing_generate_sitemap_xml()
{
    $pages = pixelbart_landing_get_sitemap_pages();

    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    foreach ($pages as $page) {
        $xml .= '<url>' . "\n";
        $xml .= '<loc>' . $page['page_url'] . '</loc>' . "\n";
        $xml .= '<lastmod>' . date('c', strtotime($page['updated_at'])) . '</lastmod>' . "\n";
        $xml .= '</url>' . "\n";
    }

    $xml .= '</urlset>';

    $dir = wp_upload_dir();
    $path = trailingslashit($dir['basedir']) . 'pixelbart-sitemaps/';

    if (!file_exists($path)) {
        mkdir($path);
    }

    $file = trailingslashit($path) . 'sitemap.xml';

    file_put_contents($file, $xml);
}

function pixelbart_landing_get_sitemap()
{
    $dir = wp_upload_dir();
    return trailingslashit($dir['baseurl']) . 'pixelbart-sitemaps/sitemap.xml';
}