<?php
/*
Plugin Name: Pixelbart Landing Page Generator
Plugin URI: https://pixelbart.de/
Description: This plugin allows you to easily create landing pages for different locations based on a selected template. The pages are generated dynamically using rewrite rules, and can be customized with unique content and keywords for each location. Improve your SEO and drive more traffic to your website with Pixelbart LandingPage Generator.
Version: 1.4.0
Author: Pixelbart
Author URI: https://pixelbart.de/
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: pixelbart-landingpage-generator
*/

defined('ABSPATH') or exit;

define('PIXELBART_LANDING_GENERATOR_PATH', plugin_dir_path(__FILE__));
define('PIXELBART_LANDING_GENERATOR_API', '519c2bda-cb1d-4a0c-bbac-da6e414c2ba9');

foreach (glob(PIXELBART_LANDING_GENERATOR_PATH . 'functions/*.php') as $file) {
    if (file_exists($file)) {
        require_once $file;
    }
}

class PixelbartLandingPlugin
{
    public static $instance;

    public static function instance()
    {
        if (!self::$instance) {
            self::$instance = new static();
        }

        return self::$instance;
    }

    public function __construct()
    {
        register_activation_hook(__FILE__, [&$this, 'setupDatabaseTables']);
        register_activation_hook(__FILE__, [&$this, 'loadTextdomain']);

        add_shortcode('pxbt_location', [&$this, 'shortcodeLocation']);

        add_action('admin_menu', [&$this, 'registerAdminMenu']);

        add_filter('query_vars', [&$this, 'registerQueryVars']);
        add_action('init', [&$this, 'registerRewriteTagsRules']);
        add_action('pre_get_posts', [&$this, 'replaceTemplateQuery'], 1);
        add_filter('pre_get_document_title', [&$this, 'replaceTemplateTitle']);
    }

    public function setupDatabaseTables()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $query = [];

        $table_name = $wpdb->prefix . 'pxbt_landing_pages';

        $query[] = "CREATE TABLE $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            page_user bigint(20) UNSIGNED NOT NULL,
            page_name varchar(255) NOT NULL,
            page_url varchar(255) NOT NULL,
            page_template bigint(20) UNSIGNED NOT NULL,
            page_location varchar(255) NOT NULL,
            created_at timestamp NOT NULL DEFAULT current_timestamp(),
            updated_at timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        ) $charset_collate;";

        $table_name = $wpdb->prefix . 'pxbt_landing_options';

        $query[] = "CREATE TABLE $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            option_name varchar(255) NOT NULL,
            option_value longtext DEFAULT NULL,
            created_at timestamp NOT NULL DEFAULT current_timestamp(),
            updated_at timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($query);
    }

    public function loadTextdomain()
    {
        load_plugin_textdomain(
            'pixelbart-landingpage-generator',
            false,
            PIXELBART_LANDING_GENERATOR_PATH . 'languages'
        );

        $source_dir = PIXELBART_LANDING_GENERATOR_PATH . 'languages';
        $target_dir = WP_LANG_DIR . '/plugins';

        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        $file_list = glob($source_dir . '/*.po');
        $file_list = array_merge($file_list, glob($source_dir . '/*.mo'));

        foreach ($file_list as $file) {
            $filename = basename($file);
            $target_file = $target_dir . '/' . $filename;
            if (file_exists($target_file)) {
                unlink($target_file);
            }
            copy($file, $target_file);
        }
    }

    public function shortcodeLocation()
    {
        global $pxbt_location;
        return $pxbt_location ?: pixelbart_landing_get_option('default_location', 'Pulheim');
    }

    public function registerAdminMenu()
    {
        $name = esc_html__('Landing Pages', 'pixelbart-landingpage-generator');

        add_menu_page($name, $name, 'manage_options', 'pixelbart-landingpage-generator-options', [&$this, 'renderLandingPage'], 'dashicons-rest-api', null);
    }

    public function renderLandingPage()
    {
        include PIXELBART_LANDING_GENERATOR_PATH . 'templates/index.php';
    }

    public function registerQueryVars($vars)
    {
        $vars[] = 'pxbt_landing_base';
        $vars[] = 'pxbt_landing_page';
        return $vars;
    }

    public function registerRewriteTagsRules()
    {
        add_rewrite_tag('%pxbt_landing_base%', '([^/]+)');
        add_rewrite_tag('%pxbt_landing_page%', '([^/]+)');

        $rewrite_base = pixelbart_landing_get_option('rewrite_base', 'service');

        add_rewrite_rule(
            "^{$rewrite_base}/([^/]+)/?$",
            'index.php?pxbt_landing_base=' . $rewrite_base . '&pxbt_landing_page=$matches[1]',
            'top'
        );
    }

    public function replaceTemplateQuery($query)
    {
        $landing_base = get_query_var('pxbt_landing_base');
        $landing_page = get_query_var('pxbt_landing_page');

        if ($query->is_main_query() && $landing_base && $landing_page) {
            $landing = pixelbart_landing_find_page_by_query_vars($landing_base, $landing_page);

            if ($landing) {
                $query->set('page_id', $landing->page_template);
                $query->set('is_single', true);
                $query->set('post_type', 'page');
                $query->set('page', '');
                $query->set('pagename', '');
                $query->is_page = true;
                $query->is_singular = true;
                $query->is_home = false;
                $query->is_archive = false;


                global $pxbt_location;

                $pxbt_location = $landing->page_location;
            }
        }
    }

    public function replaceTemplateTitle($title)
    {
        $landing_base = get_query_var('pxbt_landing_base');
        $landing_page = get_query_var('pxbt_landing_page');

        if ($landing_base && $landing_page) {
            $landing = pixelbart_landing_find_page_by_query_vars($landing_base, $landing_page);
            if ($landing) {
                $title = $landing->page_name . ' - ' . get_bloginfo('name');
            }
        }

        return $title;
    }
}

PixelbartLandingPlugin::instance();
