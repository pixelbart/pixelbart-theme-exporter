<?php
defined('ABSPATH') or exit;

$rewrite_base = pixelbart_landing_get_option('rewrite_base', 'service');
$locations = [];
$count = 0;
$location = '';
$radius = 10;

if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'pixelbart-landing-search-locations')) {

    $location = sanitize_text_field($_POST['location']);
    $radius = (int) sanitize_text_field($_POST['radius']);

    $request = pixelbart_Landing_get_locations($location, $radius);

    if ($request->success) {
        $locations = $request->locations;
        $count = $request->count;
    }
}

if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'pixelbart-landing-insert-locations')) {
    $template = sanitize_text_field($_POST['template']);
    $posted_locations = array_map('sanitize_text_field', (array) $_POST['locations']);
    $page = get_post($template);

    if (!empty($posted_locations) && $page) {
        pixelbart_landing_set_option('last_template_id', $page->ID);

        $inserted = [];
        foreach ($posted_locations as $location) {
            $status = pixelbart_landing_insert_page([
                'page_name' => sprintf('%s in %s', $page->post_title, $location),
                'page_url' => site_url('/' . $rewrite_base . '/' . sanitize_title($location . ' ' . $page->post_title)),
                'page_template' => $page->ID,
                'page_location' => $location,
            ]);

            if ($status) {
                $inserted[] = $location;
            }
        }

        printf(
            '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
            sprintf(
                esc_html__('In total, %d of %d landing pages were created.', 'pixelbart-landingpage-generator'),
                count($inserted),
                count($posted_locations)
            )
        );
    } else {
        printf(
            '<div class="notice notice-danger is-dismissible"><p>%s</p></div>',
            esc_html__('An error has occurred.', 'pixelbart-landingpage-generator')
        );
    }
}
?>

<form method="post" style="margin-top: 1rem">
    <?php wp_nonce_field('pixelbart-landing-search-locations'); ?>

    <p>
        <label for="location"><?php echo esc_html__('Location:', 'pixelbart-landingpage-generator'); ?> <sup>*</sup></label>
        <input class="regular-text" type="text" name="location" id="location" value="<?= esc_html($location) ?>" required>
    </p>

    <p>
        <label for="radius"><?php echo esc_html__('Radius:', 'pixelbart-landingpage-generator'); ?> <sup>*</sup></label>
        <input class="regular-text" type="number" name="radius" id="radius" value="<?= esc_html($radius) ?>" min="0" max="25" required>
    </p>

    <p>
        <input type="submit" value="<?php echo esc_html__('Search locations', 'pixelbart-landingpage-generator'); ?>" class="button-primary" />
    </p>
</form>

<?php if ($locations && $pages = pixelbart_Landing_get_templates()) : ?>
    <?php $current_location = $location; ?>
    <hr>
    <form method="post">
        <?php wp_nonce_field('pixelbart-landing-insert-locations'); ?>

        <p>
            <label for="template"><?php echo esc_html__('Template:', 'pixelbart-landingpage-generator'); ?> <sup>*</sup></label>
            <select class="regular-text" name="template" id="template" required>
                <?php foreach ($pages as $page_id => $page_title) : ?>
                    <option value="<?= esc_attr($page_id) ?>"><?= esc_html($page_title) ?></option>
                <?php endforeach; ?>
            </select>
        </p>

        <p><?= esc_html__('Choose locations for Landing Pages:', 'pixelbart-landingpage-generator') ?></p>

        <p>
            <label>
                <input type="checkbox" name="locations[]" value="<?= esc_html($location) ?>">
                <strong><?= esc_html($location) ?></strong>
            </label>
        </p>

        <?php foreach ($locations as $location) : ?>
            <?php if ($location->name === $current_location) continue; ?>
            <p>
                <label>
                    <input type="checkbox" name="locations[]" value="<?= esc_html($location->name) ?>">
                    <strong><?= esc_html($location->name) ?></strong>
                </label>
            </p>
        <?php endforeach; ?>

        <p>
            <input type="submit" value="<?php echo esc_html__('Save landing pages', 'pixelbart-landingpage-generator'); ?>" class="button-primary" />
        </p>
    </form>
<?php else : ?>
    <p><?= esc_html__('No pages or locations were found.', 'pixelbart-landingpage-generator') ?></p>
<?php endif; ?>