<?php

defined('ABSPATH') or exit;

$active_tab = 'pages';

if (isset($_GET['tab']) && trim($_GET['tab']) !== '') {
    switch ($_GET['tab']) {
        case 'settings':
            $active_tab = 'settings';
            break;
        case 'pages':
            $active_tab = 'pages';
            break;
        case 'edit':
            $active_tab = 'edit';
            break;
        default:
            $active_tab = 'generator';
    }
}
?>


<div class="wrap">
    <h1><?php echo esc_html__('Landing Page Generator', 'pixelbart-landingpage-generator'); ?></h1>

    <h2 class="nav-tab-wrapper">
        <a href="<?= esc_url(add_query_arg('tab', 'pages')) ?>" class="nav-tab <?php echo $active_tab == 'pages' ? 'nav-tab-active' : ''; ?>">
            <?php echo esc_html__('Pages', 'pixelbart-landingpage-generator'); ?>
        </a>
        <a href="<?= esc_url(add_query_arg('tab', 'generator')) ?>" class="nav-tab <?php echo $active_tab == 'generator' ? 'nav-tab-active' : ''; ?>">
            <?php echo esc_html__('Generator', 'pixelbart-landingpage-generator'); ?>
        </a>
        <a href="<?= esc_url(add_query_arg('tab', 'settings')) ?>" class="nav-tab <?php echo $active_tab == 'settings' ? 'nav-tab-active' : ''; ?>">
            <?php echo esc_html__('Settings', 'pixelbart-landingpage-generator'); ?>
        </a>
    </h2>

    <div class="tabs-content">

        <?php
        switch ($active_tab) {
            case 'pages':
                include PIXELBART_LANDING_GENERATOR_PATH . 'templates/pages.php';
                break;
            case 'settings':
                include PIXELBART_LANDING_GENERATOR_PATH . 'templates/settings.php';
                break;
            case 'edit':
                include PIXELBART_LANDING_GENERATOR_PATH . 'templates/edit.php';
                break;
            default:
                include PIXELBART_LANDING_GENERATOR_PATH . 'templates/generator.php';
        }
        ?>

    </div>
</div>

<?php $toplevelclass = '.toplevel_page_pixelbart-landingpage-generator-options '; ?>
<style>
    <?= $toplevelclass ?>label {
        display: block;
    }

    <?= $toplevelclass ?>label sup {
        color: red;
    }
</style>