<?php
defined('ABSPATH') or exit;

$location = pixelbart_landing_get_page_by_id($_GET['id']);

if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'pixelbart-landing-edit-location')) {
    $location = pixelbart_landing_update_page($location->id, [
        'page_template' => $_POST['template'],
    ]);

    printf(
        '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
        esc_html__('Your changes are saved.', 'pixelbart-landingpage-generator')
    );
}

$pages = pixelbart_Landing_get_templates();
?>

<form method="post" style="margin-top: 1rem">
    <?php wp_nonce_field('pixelbart-landing-edit-location'); ?>

    <p>
        <label for="template"><?php echo esc_html__('Template:', 'pixelbart-landingpage-generator'); ?> <sup>*</sup></label>
        <select class="regular-text" name="template" id="template" required>
            <?php foreach ($pages as $page_id => $page_title) : ?>
                <option value="<?= esc_attr($page_id) ?>" <?php selected($page_id, $location->page_template); ?>><?= esc_html($page_title) ?></option>
            <?php endforeach; ?>
        </select>
    </p>

    <p>
        <input type="submit" value="<?php echo esc_html__('Update location', 'pixelbart-landingpage-generator'); ?>" class="button-primary" />
    </p>
</form>