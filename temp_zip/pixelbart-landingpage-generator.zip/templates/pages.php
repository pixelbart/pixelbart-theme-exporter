<?php

defined('ABSPATH') or exit;

pixelbart_Landing_generate_sitemap_xml();

if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'pixelbart-landing-edit-locations')) {
    $deleted = 0;
    $total = 0;
    if (isset($_POST['landing_pages']) && !empty($_POST['landing_pages'])) {
        $landing_pages = array_map('intval', $_POST['landing_pages']);
        $total = count($landing_pages);

        foreach ($landing_pages as $landing_page_id) {
            $deleted += pixelbart_landing_remove_page($landing_page_id);
        }
    }

    printf(
        '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
        sprintf(
            esc_html__('%d of %d landing pages were deleted.', 'pixelbart-landingpage-generator'),
            $deleted,
            $total
        )
    );
}

$search = null;

if (isset($_GET['s']) && trim($_GET['s']) !== '') {
    $search = $_GET['s'];
}

$page = 1;
$limit = 10;

if (isset($_GET['index_page']) && is_numeric($_GET['index_page']) && $_GET['index_page'] > 0) {
    $page = intval($_GET['index_page']);
}

$query = pixelbart_landing_get_pages_query($page, $limit, $search);

if (!$query->posts) {
    echo '<p>' . esc_html__('No pages found.', 'pixelbart-landingpage-generator') . '</p>';
    return;
}
?>

<form method="get" class="search-box alignright" style="margin-top: 1rem; margin-bottom: 1rem;">
    <?php if (!empty($_GET)) : ?>
        <?php foreach ($_GET as $key => $value) : ?>
            <input type="hidden" name="<?=esc_attr($key)?>" value="<?=esc_html($value)?>">
        <?php endforeach; ?>
    <?php endif; ?>

    <label class="screen-reader-text" for="post-search-input"><?= esc_html__('Search Pages:', 'pixelbart-landingpage-generator') ?></label>
    <input type="search" id="post-search-input" name="s" value="<?=esc_html($search ?: '')?>">
    <input type="submit" id="search-submit" class="button" value="<?= esc_html__('Search Pages', 'pixelbart-landingpage-generator') ?>">
</form>

<form id="indexform" method="post">
    <div class="tablenav top">
        <div class="alignleft actions bulkactions">
            <?php wp_nonce_field('pixelbart-landing-edit-locations'); ?>
            <label for="bulk-action-selector-top" class="screen-reader-text"><?= esc_html__('Select bulk action', 'pixelbart-landingpage-generator') ?></label>
            <select name="action" id="bulk-action-selector-top">
                <option value="-1"><?= esc_html__('Bulk actions', 'pixelbart-landingpage-generator') ?></option>
                <option value="trash"><?= esc_html__('Remove', 'pixelbart-landingpage-generator') ?></option>
            </select>
            <input type="submit" class="button action" value="<?= esc_html__('Apply', 'pixelbart-landingpage-generator') ?>">
        </div>

        <div class="tablenav-pages">
            <span class="displaying-num"><?= $query->post_count ?> <?= esc_html__('Items', 'pixelbart-landingpage-generator') ?></span>

            <?php if ((int) $query->paged > 1) : ?>
                <a class="prev-page button" href="<?= add_query_arg('index_page', $query->paged - 1) ?>">
                    <span class="screen-reader-text"><?= esc_html__('Previous page', 'pixelbart-landingpage-generator') ?></span><span aria-hidden="true">‹</span>
                </a>
            <?php else : ?>
                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>
            <?php endif; ?>

            <span class="paging-input">
                <span class="tablenav-paging-text"><?= $query->paged ?> <?= esc_html__('of', 'pixelbart-landingpage-generator') ?> <span class="total-pages"><?= $query->max_num_pages ?></span></span>
            </span>

            <?php if ((int) $query->max_num_pages > (int) $query->paged) : ?>
                <a class="next-page button" href="<?= add_query_arg('index_page', $query->paged + 1) ?>">
                    <span class="screen-reader-text"><?= esc_html__('Next page', 'pixelbart-landingpage-generator') ?></span><span aria-hidden="true">›</span>
                </a>
            <?php else : ?>
                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>
            <?php endif; ?>
        </div>
    </div>

    <table class="wp-list-table widefat fixed striped posts" style="margin-top: 1rem">
        <thead>
            <tr>
                <td id="cb" class="manage-column column-cb check-column">
                    <label class="screen-reader-text" for="cb-select-all-1"><?= esc_html__('Select All', 'pixelbart-landingpage-generator') ?></label>
                    <input id="cb-select-all-1" type="checkbox">
                </td>
                <th scope="col" class="manage-column column-title column-primary"><?= esc_html__('Title', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-location column-primary"><?= esc_html__('Location', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-template column-primary"><?= esc_html__('Template', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-author"><?= esc_html__('Author', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-date"><?= esc_html__('Created', 'pixelbart-landingpage-generator') ?></th>
            </tr>
        </thead>

        <tbody id="the-list">
            <?php foreach ($query->posts as $page) : ?>
                <?php $template = get_post($page->page_template); ?>
                <tr id="post-<?= $page->id ?>" class="iedit author-self level-0 post-<?= $page->id ?> type-post status-publish format-standard hentry category-Dummy category">
                    <th scope="row" class="check-column">
                        <label class="screen-reader-text" for="cb-select-<?= $page->id ?>"><?= esc_html__('Select page', 'pixelbart-landingpage-generator') ?></label>
                        <input id="cb-select-<?= $page->id ?>" type="checkbox" name="landing_pages[]" value="<?= $page->id ?>">
                        <div class="locked-indicator">
                            <span class="locked-indicator-icon" aria-hidden="true"></span>
                            <span class="screen-reader-text">
                                <?= esc_html__('Page is locked', 'pixelbart-landingpage-generator') ?>
                            </span>
                        </div>
                    </th>
                    <td class="title column-title has-row-actions column-primary page-title" data-colname="<?= esc_html__('Title', 'pixelbart-landingpage-generator') ?>">
                        <strong>
                            <a target="_blank" class="row-title" href="<?= esc_url($page->page_url) ?>" aria-label="<?= esc_attr($page->page_name) ?> <?= esc_html__('(View)', 'pixelbart-landingpage-generator') ?>"><?= esc_html($page->page_name) ?></a>
                        </strong>

                        <div class="row-actions">
                            <span class="trash"><a href="#" class="submitdelete" aria-label="<?= esc_html__('Remove', 'pixelbart-landingpage-generator') ?> <?= esc_attr($page->page_name) ?>"><?= esc_html__('Remove', 'pixelbart-landingpage-generator') ?></a> | </span>
                            <span class="view"><a target="_blank" href="<?= esc_url($page->page_url) ?>" rel="bookmark" aria-label="<?= esc_html__('View', 'pixelbart-landingpage-generator') ?> <?= esc_attr($page->page_name) ?>"><?= esc_html__('View', 'pixelbart-landingpage-generator') ?></a> | </span>
                            <span class="edit"><a target="_self" href="<?= esc_url(add_query_arg(['tab' => 'edit', 'id' => $page->id, 'page' => 'pixelbart-landingpage-generator-options'], admin_url('admin.php'))) ?>" aria-label="<?= esc_html__('Edit', 'pixelbart-landingpage-generator') ?> <?= esc_attr($page->page_name) ?>"><?= esc_html__('Edit', 'pixelbart-landingpage-generator') ?></a></span>
                        </div>
                    </td>
                    <td class="location column-location" data-colname="<?= esc_html__('Location', 'pixelbart-landingpage-generator') ?>">
                        <?= esc_html($page->page_location) ?>
                    </td>
                    <td class="template column-template" data-colname="<?= esc_html__('Template', 'pixelbart-landingpage-generator') ?>">
                        <a target="_blank" href="<?= get_the_permalink($template->ID) ?>" title=""><?= esc_html($template->post_title) ?></a>
                    </td>
                    <td class="author column-author" data-colname="<?= esc_html__('Author', 'pixelbart-landingpage-generator') ?>">
                        <?php $author = get_user_by('id', $page->page_user); ?>
                        <?= esc_html($author->display_name) ?>
                    </td>
                    <td class="date column-date" data-colname="<?= esc_html__('Date', 'pixelbart-landingpage-generator') ?>">
                        <?= gmdate(esc_html__('Y-m-d H:i:s', 'pixelbart-landingpage-generator'), strtotime($page->created_at)) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td class="manage-column column-cb check-column">
                    <label class="screen-reader-text" for="cb-select-all-2"><?= esc_html__('Select All', 'pixelbart-landingpage-generator') ?></label>
                    <input id="cb-select-all-2" type="checkbox">
                </td>
                <th scope="col" class="manage-column column-title column-primary"><?= esc_html__('Title', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-location column-primary"><?= esc_html__('Location', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-template column-primary"><?= esc_html__('Template', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-author"><?= esc_html__('Author', 'pixelbart-landingpage-generator') ?></th>
                <th scope="col" class="manage-column column-date"><?= esc_html__('Created', 'pixelbart-landingpage-generator') ?></th>
            </tr>
        </tfoot>
    </table>

    <div class="tablenav bottom">
        <div class="tablenav-pages">
            <span class="displaying-num"><?= $query->post_count ?> <?= esc_html__('Items', 'pixelbart-landingpage-generator') ?></span>

            <?php if ((int) $query->paged > 1) : ?>
                <a class="prev-page button" href="<?= add_query_arg('index_page', $query->paged - 1) ?>">
                    <span class="screen-reader-text"><?= esc_html__('Previous page', 'pixelbart-landingpage-generator') ?></span><span aria-hidden="true">‹</span>
                </a>
            <?php else : ?>
                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>
            <?php endif; ?>

            <span class="paging-input">
                <span class="tablenav-paging-text"><?= $query->paged ?> <?= esc_html__('of', 'pixelbart-landingpage-generator') ?> <span class="total-pages"><?= $query->max_num_pages ?></span></span>
            </span>

            <?php if ((int) $query->max_num_pages > (int) $query->paged) : ?>
                <a class="next-page button" href="<?= add_query_arg('index_page', $query->paged + 1) ?>">
                    <span class="screen-reader-text"><?= esc_html__('Next page', 'pixelbart-landingpage-generator') ?></span><span aria-hidden="true">›</span>
                </a>
            <?php else : ?>
                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>
            <?php endif; ?>
        </div>
    </div>

    <script>
        (function($) {
            $('.submitdelete').on('click', function(e) {
                e.preventDefault();
                var item = $(this).closest('.level-0');

                item.find('[type="checkbox"]').prop('checked', 'checked');
                $('#bulk-action-selector-top').val('trash');
                $('#indexform').trigger('submit');
            });
        })(jQuery);
    </script>