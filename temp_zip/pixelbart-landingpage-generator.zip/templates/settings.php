<?php
defined('ABSPATH') or exit;

pixelbart_Landing_generate_sitemap_xml();

if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'pixelbart-landing-settings')) {

    $options = [];

    if (isset($_POST['options']) && is_array($_POST['options'])) {
        $options = array_map('sanitize_text_field', $_POST['options']);
    }

    if (!empty($options)) {
        foreach ($options as $option_name => $option_value) {
            pixelbart_landing_set_option($option_name, $option_value);
        }
    }

    printf(
        '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
        esc_html__('Settings saved.', 'pixelbart-landingpage-generator')
    );
}
?>

<form method="post" style="margin-top: 1rem">
    <?php wp_nonce_field('pixelbart-landing-settings'); ?>

    <p>
        <?=esc_html__('Sitemap:', 'pixelbart-landingpage-generator')?> <a href="<?=pixelbart_landing_get_sitemap()?>" target="_blank">
            <?=esc_html__('Open sitemap', 'pixelbart-landingpage-generator')?>
        </a>
    </p>

    <p>
        <?php $value = pixelbart_landing_get_option('rewrite_base', 'service'); ?>
        <label for="rewrite_base"><?php echo esc_html__('Rewrite base:', 'pixelbart-landingpage-generator'); ?> <sup>*</sup></label>
        <input type="text" id="rewrite_base" name="options[rewrite_base]" value="<?=esc_html($value)?>" class="regular-text code" required>
    </p>

    <p>
        <?php $value = pixelbart_landing_get_option('default_location', 'Pulheim'); ?>
        <label for="default_location"><?php echo esc_html__('Default location:', 'pixelbart-landingpage-generator'); ?> <sup>*</sup></label>
        <input type="text" id="default_location" name="options[default_location]" value="<?=esc_html($value)?>" class="regular-text code" required>
    </p>

    <p>
        <input type="submit" value="<?php echo esc_html__('Save settings', 'pixelbart-landingpage-generator'); ?>" class="button-primary" />
    </p>
</form>